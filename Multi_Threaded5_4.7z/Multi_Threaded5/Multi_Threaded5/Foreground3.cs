﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    public class Foreground3 : Background
    {

        // MTBench2 on Main Thread
        public Foreground3()
        {

            GC.Collect();
            GC.WaitForFullGCComplete();

            try
            {
                // main thread will be the last one
                Thread.Sleep(5000);
         

                DSingle2();

               

            }

            catch (Exception ex)
            {

                const string path = "log" + "_" + "Foreground2.Constructor" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }

        }











    }
}

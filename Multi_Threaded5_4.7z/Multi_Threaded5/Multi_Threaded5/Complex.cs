﻿//using System;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;

//using System.Text;
//using System.Threading.Tasks;
using System.Runtime.Intrinsics;
using Crc32C;

namespace Multi_Threaded5
{

   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    // This class does contain Complex Math algorithms that can stress the cpu and memory
    // 2025.05.04: Protected algorithms will be changed to private and they will be loaded into protected readonly delegates to optimize performance and security
    // delegates are only accessed in child class(TaskManager.cs)
    public class Complex 
    {
        // it must be used only from TaskManager.cs
        //protected Stopwatch Garmin = new Stopwatch();

        protected Stopwatch Garmin = new();

        //protected Stopwatch Interval = new Stopwatch();

        protected Stopwatch Interval = new();


        protected delegate int BinaryDel1(int[] nums, int target);

        protected delegate Int128 BinaryDel2(Int128[] nums, Int128 target);

        protected delegate UInt128 BinaryDel3(UInt128[] nums, UInt128 target);

        protected delegate int InterDel1(byte[] arr, byte target);

        protected delegate double FibonacciDel1(int n);

        protected delegate int FactDel1(int n);

        protected readonly BinaryDel1 BDel1;

        protected readonly BinaryDel2 BDel2;

        protected readonly BinaryDel3 BDel3;

        protected readonly FibonacciDel1 FibDel1;

        protected readonly FibonacciDel1 FibDel2;

        protected readonly FactDel1 FactD1;

        protected readonly InterDel1 IDel1;

        
        // 30 seconds for testing
        //protected static readonly uint TimeLimit = 30000;


        //protected static ulong work = 0;

        protected static long Score { get; set; }


        //protected bool is_busy { get; set;}


        // 2025.05.13
        public Complex()
        {
            BDel1 = BinarySearch;

            BDel2 = BinarySearch3;

            BDel3 = BinarySearch4;

            FibDel1 = Fibonacci;

            FactD1 = Factorial;

            IDel1 = InterpolationSearch2;

            // Fibonacci + Factorial for Benchmark
            // it has moved to Benchmark.dll written in C++
            FibDel2 = Fibonacci2;

            Score = 0;
  
        }


        //protected int score { get; set; }




        // Fibonacci 
        private static double Fibonacci(int n)
        {
            if (n <= 1)
                return n;
            else
                return Fibonacci(n - 1) + Fibonacci(n - 2);
        }

        

        
        private static double Fibonacci2(int n)
        {
            if (n <= 1)
                return n;
            else
                return Factorial(n - 1);
        }


      


        // BubbleSort
        //public void BubbleSort(int n)
        //{
        //    //Random r = new Random();

        //    //int n = r.Next(128,);

        //    int []arr = new int[n]; 

        //    for (int i = 0; i < n; i++)
        //    {
        //        for (int j = 0; j < n - 1; j++)
        //        {
        //            if (arr[j] > arr[j + 1])
        //            {
        //                int temp = arr[j];
        //                arr[j] = arr[j + 1];
        //                arr[j + 1] = temp;
        //            }
        //        }
        //    }

        //}



        // Binary Search 
        private static int BinarySearch(int[] nums, int target)
        {
            int low = 0, high = nums.Length - 1, mid = (low + high) / 2;
            while (low <= high)
            {
                if (nums[mid] == target) return mid;
                if (nums[mid] > target) high = mid - 1;
                if (nums[mid] < target) low = mid + 1;
               
                mid = (low + high) / 2;
            }

            Score ++;
           
            return -1;
        }



        // Binary Search for lists
        private static int BinarySearch2(List<double> nums, int target)
        {
            int low = 0, high = nums.Count - 1, mid = (low + high) / 2;
            while (low <= high)
            {
                if (nums[mid] == target) return mid;
                if (nums[mid] > target) high = mid - 1;
                if (nums[mid] < target) low = mid + 1;
                mid = (low + high) / 2;
            }
            return -1;
        }

        // BDel2
        private static Int128 BinarySearch3(Int128[] nums, Int128 target)
        {
            int low = 0, high = nums.Length - 1, mid = (low + high) / 2;
            while (low <= high)
            {
                if (nums[mid] == target) return mid;
                if (nums[mid] > target) high = mid - 1;
                if (nums[mid] < target) low = mid + 1;
                mid = (low + high) / 2;
            }

            Score++;

            return -1;
        }

        // Bdel3
        private static UInt128 BinarySearch4(UInt128[] nums, UInt128 target)
        {
            uint low = 0, high = (uint)nums.Length - 1, mid = (low + high) / 2;
            while (low <= high)
            {
                if (nums[mid] == target) return mid;
                if (nums[mid] > target) high = mid - 1;
                if (nums[mid] < target) low = mid + 1;
                mid = (low + high) / 2;
            }

            //Score++;

            return 0;
        }



        // Binary Search for string array
        private static int BinaryString(string[] arr, string x)
        {

            int l = 0;
            int r = arr.Length - 1;

            // Loop to implement Binary Search
            while (l <= r)
            {

                // Calculating mid
                int m = l + (r - l) / 2;

                // Check if x is present at mid
                if (arr[m] == x)
                {
                    return m;
                }

                // If x greater, ignore left half
                if (arr[m].CompareTo(x) < 0)
                {
                    l = m + 1;
                }

                // If x is smaller, ignore right half
                else
                {
                    r = m - 1;
                }
            }

            return -1;
        }




        // Interpolation Search

        private static int InterpolationSearch(int[] arr, int target)
        {
            int left = 0;
            int right = arr.Length - 1;

            while (left <= right && target >= arr[left] && target <= arr[right])
            {
                int pos = left + ((target - arr[left]) * (right - left)) / (arr[right] - arr[left]);

                if (arr[pos] == target)
                    return pos;
                else if (arr[pos] < target)
                    left = pos + 1;
                else
                    right = pos - 1;
            }

            
            return -1; // target not found
        }


        // max: 255
        // 2025.05.13
        // Crc32C.NET.dll
        private static int InterpolationSearch2(byte[] arr, byte target)
        {
            int left = 0;
            int right = arr.Length - 1;

            while (left <= right && target >= arr[left] && target <= arr[right])
            {
                int pos = left + ((target - arr[left]) * (right - left)) / (arr[right] - arr[left]);

                if (arr[pos] == target)
                    return pos;
                else if (arr[pos] < target)
                    left = pos + 1;
                else
                    right = pos - 1;
            }


            Crc32CAlgorithm.Compute(arr, left, right);

            Score++;

            //Factorial2(12980);

         
            return -1; // target not found
        }









        // 2D Binary Search
        //public int BinarySearch2D(int[,] nums, int target)
        //{
        //    int low = 0, high = nums.Length - 1, mid = (low + high) / 2;
        //    while (low <= high)
        //    {
        //        if (nums[mid,mid] == target) return mid;
        //        if (nums[mid,mid] > target) high = mid - 1;
        //        if (nums[mid,mid] < target) low = mid + 1;
        //        mid = (low + high) / 2;
        //    }
        //    return -1;
        //}



        // Factorial
        private static int Factorial(int a)
        {
            int fact = 1;
            for (int x = 1; x <= a; x++)
            {
                fact *= x;
            }

            Score ++;

            return fact;    

        }


        private static Int128 Factorial2(Int128 a)
        {
            int fact = 1;
            for (int x = 1; x <= a; x++)
            {
                fact *= x;
            }

            Score ++;

            return fact;

        }


        // structs are much faster than classes with smaller projects
        //public struct MyStruct
        //{
        //    public MyStruct(int a, int b)
        //    {
        //        A = a;

        //        B = b;

        //    }

        //    public int A { get; set;}

        //    public int B { get; set; }


        //}



        // Prime25
        private static string Prime25(int n)
        {

            int a = 0;

            for (int i = 1; i <= n; i++)
            {
                if (n % i == 0)
                {
                    a++;
                }
            }
            if (a == 2)
            {
                return "Prime";
            }
            else
            {
                return "Not Prime";
            }
        }


    }




}

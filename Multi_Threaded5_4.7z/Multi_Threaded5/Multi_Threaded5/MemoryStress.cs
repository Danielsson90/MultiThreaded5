﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Buffers;
using System.Diagnostics;
using System.IO;

namespace Multi_Threaded5
{
    public class MemoryStress : Complex2
    {

        MemoryInfo Memory = new();

        //private static Stopwatch Garmin = new();

        //private static Stopwatch Interval = new();


        private byte Menu {get; set;}

        private int FreeMemory { get; set;}

        //private int VirtualMemory { get; set; }

        private int TestedMemory { get; set;}

        
        public MemoryStress()
        {
            GC.Collect();

            GC.WaitForFullGCComplete();

            Menu = 0;
        

            FreeMemory = Memory.GetAvailableMemory();


            //VirtualMemory = GetVirtualMemory();   
            
            Thread.Sleep(2000);

            MemoryMenu();
        
        
              
        }

        private void MemoryMenu()
        {
            Console.Clear();

            Console.WriteLine("Free Physical Memory: " + FreeMemory.ToString());

           

            Console.WriteLine("\nThis is the Memory Stress Test x64.");
            Console.WriteLine("Choose from the settings below:");
            Console.WriteLine("1: Test All Available memory. 2: Type in memory-size");

            Console.WriteLine(Imported.CpuDel);

            Menu = byte.Parse(Console.ReadLine());
            //Console.ReadKey();


            switch (Menu)
            {
                case 1:
                    SetTask();
                    break;

                    case 2:
                    TestSelectedMemory(); 
                    break;
            }


        }

        private void SetTask()
        {
            
            ThreadPool.SetMinThreads(DataBase.CPU.CoreCount, DataBase.CPU.ThreadCount);

            //Info.GetThreadCount() - 1
            for (int i = 0; i < DataBase.CPU.ThreadCount - 1; i++)
            {
                ThreadPool.QueueUserWorkItem(TestAllMemory);

            }

            Thread.Sleep(2000);


            // Main Thread
            TestAllMemory_Single();


        }



        private void TestAllMemory(Object stateInfo)
        {
            try
            {

                //Garmin.Start();


                //short[] src = { 258, 259, 260, 261, 262, 263, 264,
                //          265, 266, 267, 268, 269, 270 };
                //long[] dest = { 17, 18, 19, 20 };

                //byte[] src2 = { 64, 65, 66, 81, 82, 83, 84, 85, 86, 128, 129, 130, 255 }; 

                //Console.WriteLine("Multi Threaded 5 is about to test your memory, please close any background applications. If you experience any stability issues, change your RAM settings.");


                MemD1_M(FreeMemory);



                //Console.WriteLine("Memory test completed successfully.");

            }


            catch (Exception ex)
            {
                const string Path = "log" + "_" + "MemoryStress.TestAllMemory" + ".txt";

                DateTime Date = DateTime.Now;

                Console.WriteLine(ex.Message);

                Imported.Mbox(0, "Error: " + ex.Message, "Multi Threaded 5", 0);

                File.WriteAllText(Path, Date.ToString() + " " + ex.Message + " " + ex.Source);

            }


        }


        private void TestAllMemory_Single()
        {
            try
            {
                Console.WriteLine("Multi Threaded 5 is about to test your memory, please close any background applications. If you experience any stability issues, change your RAM settings.");


                MemD1_S(FreeMemory);



                Console.WriteLine("Memory test completed successfully.");

            }


            catch (Exception ex)
            {
                const string Path = "log" + "_" + "MemoryStress.TestAllMemory" + ".txt";

                DateTime Date = DateTime.Now;

                Console.WriteLine(ex.Message);

                Imported.Mbox(0, "Error: " + ex.Message, "Multi Threaded 5", 0);

                File.WriteAllText(Path, Date.ToString() + " " + ex.Message + " " + ex.Source);

            }

        }


        private void TestSelectedMemory()
        {
            Console.WriteLine("\nType in memory size: ");
            TestedMemory = int.Parse(Console.ReadLine());

            Console.ReadKey();  
        }


    }
}

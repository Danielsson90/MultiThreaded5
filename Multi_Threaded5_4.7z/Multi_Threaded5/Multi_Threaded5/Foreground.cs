﻿using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Diagnostics;
using System.IO;
using System.Threading;
//using System.Management;





namespace Multi_Threaded5
{

   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    // It is the MainThread, it must be executed after all background threads if you use infinite loops
    public class Foreground : Background
    {

        // Stopwatch class helps measuring performance
        // It is useful if you are about to add benchmark
        //private static Stopwatch garmin = new Stopwatch();



        // Stress Test Main THread
        public Foreground()
        {


            
            try
            {
                
                // main thread will be the last one
                Thread.Sleep(4000);


                            
                    TaskManager.Task2Single();

                      
            }
            catch (Exception ex)
            {

                const string path = "log" + "_" + "Foreground.Constructor" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }

              
        }

        // Application Exit Event
      




        // It is running on MainThread only, MainThread is always the last one





    }
           




        




      
 }


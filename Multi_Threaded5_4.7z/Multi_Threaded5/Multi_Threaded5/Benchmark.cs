﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.IO;
using System.Threading;
//using System.Diagnostics;

namespace Multi_Threaded5
{
    public class Benchmark : Background
    {

           

        public Benchmark()
        {
            

            GC.Collect();
            GC.WaitForFullGCComplete();
            Console.Clear();


            Console.Clear();
            //Console.WriteLine("Benchmark mode:");



            // benchmark type
            // 1:Fibonacci2+Factorial - ThreadPool, 2:Fibonacci2+Factorial  - Manual Threads
            // 3: BinaryBench2 - ThreadPool
            switch (DataBase.Config.BenchMode)
            {
                case 1:
                    SetTask1();

                    break;

                case 2:
                    SetTask2();
                    break;


                    case 3:
                    SetTask3();

                    break;

                case 4:
                    SetTask4();
                    break;  


            }

        }


        
        // Threadpool -> DMulti1
        private void SetTask1()
        {
            //ThreadPool.SetMinThreads(Info.GetCoreCount(), Info.GetThreadCount());


            ThreadPool.SetMinThreads(DataBase.CPU.CoreCount, DataBase.CPU.ThreadCount);

            //Info.GetThreadCount()-1

            try
            {
                for (int i = 0; i < DataBase.CPU.ThreadCount -1; i++)
                {
                    //ThreadPool.QueueUserWorkItem(TaskManager.BinaryBench_Multi);

                    // in case of delegates, new WaitCallback is required
                    // delegates are a little faster than direct method calls
                    // DMulti is assigned to TaksManager.BinaryBench_Multi and is readonly
                    ThreadPool.QueueUserWorkItem(new WaitCallback(DMulti1));
                }

                // main thread
                Foreground2 foreground2 = new();



            }


            catch (Exception ex)
            {

                const string path = "log" + "_" + "Benchmark.SetTask1" + ".txt";

                DateTime date = DateTime.Now;

                Console.WriteLine(ex.Message);

                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }
 
        
        }




       

        // Threads -> DMulti1T
        private void SetTask2()
        {
            
            // thread array with thread_count length
            Thread[] Threads = new Thread[DataBase.CPU.ThreadCount - 1];

           

            try
            {

                // Creating Threads: Threads_count -1 + main thread(background Threads + 1 foreground thread)
                // Optimizing Threads -> background threads: highest priority, foreground thread: normal priority
                // background threads: thread_count -1 foreground thread: 1
                for (int i = 0; i < Threads.Length; i++)
                {
                    //Threads[i] = new Thread(TaskManager.MTBench_Multi, 0);

                    Threads[i] = new Thread(DMulti1T.Invoke, 0);

                    Threads[i].IsBackground = false;

                    Threads[i].Priority = ThreadPriority.Highest;

                    Threads[i].Start();
                }



                // main thread
                Foreground2 foreground2 = new();


            }


            catch (Exception ex)
            {

                const string path = "log" + "_" + "Benchmark.SetTask2" + ".txt";

                DateTime date = DateTime.Now;

                Console.WriteLine(ex.Message);

                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }


        // Threadpool: MTBench2
        private void SetTask3()
        {
            //ThreadPool.SetMinThreads(Info.GetCoreCount(), Info.GetThreadCount());


            ThreadPool.SetMinThreads(DataBase.CPU.CoreCount, DataBase.CPU.ThreadCount);

            //Info.GetThreadCount()-1

            try
            {
                for (int i = 0; i < DataBase.CPU.ThreadCount - 1; i++)
                {
                    //ThreadPool.QueueUserWorkItem(TaskManager.BinaryBench_Multi);

                    // in case of delegates, new WaitCallback is required
                    // delegates are a little faster than direct method calls
                    // DMulti is assigned to TaksManager.BinaryBench_Multi and is readonly
                    ThreadPool.QueueUserWorkItem(new WaitCallback(DMulti2));
                }

                // main thread
                Foreground3 foreground3 = new();



            }


            catch (Exception ex)
            {

                const string path = "log" + "_" + "Benchmark.SetTask1" + ".txt";

                DateTime date = DateTime.Now;

                Console.WriteLine(ex.Message);

                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }


        // Threads: MTBench2
        private void SetTask4()
        {

            // thread array with thread_count length
            Thread[] Threads = new Thread[DataBase.CPU.ThreadCount - 1];



            try
            {

                // Creating Threads: Threads_count -1 + main thread(background Threads + 1 foreground thread)
                // Optimizing Threads -> background threads: highest priority, foreground thread: normal priority
                // background threads: thread_count -1 foreground thread: 1
                for (int i = 0; i < Threads.Length; i++)
                {
                    Threads[i] = new Thread(DMulti2.Invoke, 0);

                    Threads[i].IsBackground = false;

                    Threads[i].Priority = ThreadPriority.Highest;

                    Threads[i].Start();
                }



                // main thread
                Foreground3 foreground3 = new();


            }


            catch (Exception ex)
            {

                const string path = "log" + "_" + "Benchmark.SetTask2" + ".txt";

                DateTime date = DateTime.Now;

                Console.WriteLine(ex.Message);

                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }


    }




    }


﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
using System.Threading;
//using System.Threading.Tasks;
using System.IO;
//using System.Diagnostics;

namespace Multi_Threaded5
{
    public class Foreground2 : Background
    {

       
        
        // Benchmark Modes
        public Foreground2()
        {

            GC.Collect();
            GC.WaitForFullGCComplete();

            try
            {
                // main thread will be the last one
                Thread.Sleep(5000);
              
                //TaskManager.BinaryBench_Single();

                DSingle1();

                //if (DataBase.Config.BenchMode == 1)
                    //DSingle1();

                //if (DataBase.Config.BenchMode == 2)
                    //DSingle1();

                //if (DataBase.Config.BenchMode == 3)
                //    DSingle2();


                
            
            }

            catch (Exception ex)
            {

                const string path = "log" + "_" + "Foreground2.Constructor" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }

        }



    }
}

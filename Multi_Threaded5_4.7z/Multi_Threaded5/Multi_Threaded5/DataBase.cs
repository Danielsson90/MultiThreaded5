﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.Collections.ObjectModel;
//using System.Threading;
using System.Diagnostics;
using System.Numerics;
using System.IO;
using System.Runtime.InteropServices;




namespace Multi_Threaded5
{

   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    // created on 01.05.2025
    // Using public static class seems faster than creating new objects every time
    public static class DataBase
    {

        private static SystemInfo Info = new();

        // calling delegates are faster than calling methods, the performance penalty is only nanoseconds
        public delegate void d1(Stopwatch garmin, long score);


        // NextMethod set ShowResults for d1_pointer
        // readonly delegates can be useful when the method never changes
        // they can be even multi-cast delegates with method chain, but they must be declared on initialization
        public static d1 d1_pointer = SaveToFile;

        //public delegate int MBoxD(IntPtr hWnd, String text, String caption, uint type);


        // it is user32.dll MessageBox
        //public static MBoxD Mbox = MessageBox;  


        // read-only lists
        private static ReadOnlyCollection<string> ReadOnlyData = new ReadOnlyCollection<string>(Info.CpuDetails);



        // SystemInfo.cs reads all necessary cpu information, loads all data into CpuDetails list
        // DataBase.cs is a static class, it creates a ReadOnlyCollection, loads CpuDetails then creates readonly
        // 1: CpuName, 2: CoreCount, 3: ClockSpeed, 4: ThreadCount, 5: L2CacheSize, 6: L3CacheSize, 7: Architecture, 8: Family
        public static readonly IEnumerable<string> CpuData = new[] {"\nCpuName: " + Info.CpuDetails[0] + "\n"+"Codename: "+Info.GetCodeName(), "\nCoreCount:" + Info.CpuDetails[1],
            "\nClockSpeed: " + Info.CpuDetails[2] + " Mhz", "\nThreadCount:" + Info.CpuDetails[3],
            "\nL2CacheSize: " + Info.CpuDetails[4] + " MB", "\nL3CacheSize: " + Info.CpuDetails[5] + " MB", "\nArchitecture: " + Info.CpuDetails[6], "\nFamily: " + Info.CpuDetails[7]};


        //L2Cache and L3Cache sizes must be static readonly for future optimizations
        public readonly struct CPU
        {
            //public static readonly CPU Zero = new CPU();


            public static readonly string CpuName = Info.CpuDetails[0];
            // for serial check only
            public static readonly string CpuID = Info.CpuDetails[8];
            public static readonly int CoreCount = int.Parse(Info.CpuDetails[1]);
            public static readonly int ThreadCount = int.Parse(Info.CpuDetails[3]);
            public static readonly int ClockSpeed = int.Parse(Info.CpuDetails[2]);
            public static readonly int L2CacheSize = int.Parse(Info.CpuDetails[4]);
            public static readonly int L3CacheSize = int.Parse(Info.CpuDetails[5]);
            public static readonly int Architecture = int.Parse(Info.CpuDetails[6]);
            public static readonly int Family = int.Parse(Info.CpuDetails[7]);
        }


        // Available FreeMemory is also readable from Garbage Collector
        // Info.GetFreeMemory() reads from Win32_OperatingSystem
        // MemoryInformation should be seperated from CpuInfo as it changes in real time
        public readonly struct Memory
        {
            public static readonly UInt64 FreeMemory = Info.GetFreeMemory();

            public static readonly long AvailableMemory = GC.GetTotalMemory(true);
         
        }

           

        // InputSetting: readonly IEnumerable Collection
        // 1: cpu_load, 2: bench_mode
        public readonly struct Config
        {
            public static readonly int CpuLoad = Info.InputSettings.ElementAt(0);

            public static readonly int BenchMode = Info.InputSettings.ElementAt(1);
        }




        //SaveToFile moved to DataBase.cs, because I want to limit the call of SystemInfo
        // SystemInfo should be called only once
        private static void SaveToFile(Stopwatch garmin, long score)
        {
            DateTime Date = DateTime.Now;

            string text = Date + " " + CPU.CpuName + " " + CPU.CoreCount + "/" + CPU.ThreadCount + " " + CPU.ClockSpeed + "Mhz";

             
            File.AppendAllText("benchmark.txt", "\n" + text + " ElapsedTime: " + garmin.Elapsed.ToString() + " Score: " + score.ToString() + " Benchmode: " + DataBase.Config.BenchMode.ToString());


        }


        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);



        //ShowResults has moved to DataBase.cs
        //2025.05.03
        private static void ShowResults(Stopwatch garmin, long score)
        {
            Console.WriteLine("\nbench completed in: " + garmin.ElapsedMilliseconds);

            Console.WriteLine("\nyour score is: " + score.ToString());

            //MessageBox.Show("Bench completed in: " + garmin.ElapsedMilliseconds + "\nYour score is: " + score.ToString() +
                    //"\nYour benchmark has been saved to benchmark.txt");


            MessageBox(0, "Bench completed in: " + garmin.ElapsedMilliseconds + "\nYour score is: " + score.ToString() + "\nYour benchmark has been saved to benchmark.txt", "Multi_Threaded5",0);

            Console.WriteLine("\n" + "Your benchmark has been saved to benchmark.txt");

        }

        
        // d1 delegate works like a pointer: single-cast delegate
        public static void NextMethod()
        {
            d1_pointer = ShowResults;
        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
    public class MemoryInfo
    {
        // AvailableMemory will be read when necessary without reading CpuInfo
        private UInt64 AvailableMemory { get; set;}

        private UInt64 VirtualMemory { get; set;} 





        public MemoryInfo()
        {
            var MemorySearcher = new ManagementObjectSearcher("SELECT * FROM" + " " + "Win32_OperatingSystem");

            foreach (ManagementObject queryObj in MemorySearcher.Get())
            {
                this.AvailableMemory = UInt64.Parse($"{queryObj["FreePhysicalMemory"]}");

                this.VirtualMemory = UInt64.Parse($"{queryObj["FreeVirtualMemory"]}");

            }

        }

        // AvailableMemory is in bytes so the result needs to be divided by 1024
        public int GetAvailableMemory()
        {
            return (int)AvailableMemory / 1024;
             
        }

        
        public int GetVirtualMemory()
        {
            return (int)VirtualMemory / 1024;

        }
    }
}

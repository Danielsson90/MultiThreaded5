﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    // 1:TaskManager.cs, 2:TaskManagerPart2.cs
    // 2025.05.13
    public partial class TaskManager
    {

        private static Mutex Mut = new();





        // moved from Background2.cs
        public void Task1(Object stateInfo)
        {
            //frames = 0;
            //Garmin.Start();

            Console.WriteLine("Background Task1 is running.");

            Random r = new Random(DateTime.Now.Millisecond);




            int[] num = new int[512];


            int[] num2 = new int[512];



            try
            {




                do
                {


                    BDel1(num, r.Next(1, 999));


                    BDel1(num2, r.Next(1, 999));


                } while (true);




            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }



        //*
        // moved from Background2.cs
        public void Task2(Object stateInfo)
        {

            
            //MemoryInfo memInfo = new MemoryInfo();

            Console.WriteLine("Background Task2 is running.");


            Random r = new Random(DateTime.Now.Millisecond);



            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 1800: 6300MB
            for (int i = 0; i < 1800; i++)
            {
                Arrs.Add(new Int128[1500 * 10]);
            }

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }




            try
            {



                do
                {
                     

                    //FibDel1(r.Next(1, 256));


                    //Stress.dll -> Fibonacci
                    Imp.FibD1(r.Next(1, 256));



                    //Mut.ReleaseMutex();
                } while (true);


                


            }
            catch (Exception ex)
            {
                const string path = "log" + "_" + "Background2.Task2" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);


            }


        }

        // old Thread
        public void Task2T()
        {


            //MemoryInfo memInfo = new MemoryInfo();

            Console.WriteLine("Background Task2 is running.");


            Random r = new Random(DateTime.Now.Millisecond);



            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 1800: 6300MB
            for (int i = 0; i < 1800; i++)
            {
                Arrs.Add(new Int128[1500 * 10]);
            }

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }




            try
            {



                do
                {


                    //FibDel1(r.Next(1, 256));


                    //Stress.dll -> Fibonacci
                    Imp.FibD1(r.Next(1, 256));



                    //Mut.ReleaseMutex();
                } while (true);





            }
            catch (Exception ex)
            {
                const string path = "log" + "_" + "Background2.Task2" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);


            }


        }




        public void Task2Single()
        {
            MemoryInfo MemInfo = new MemoryInfo();

            Console.WriteLine("Foreground Task2 is running.");



            //Console.WriteLine("CPU: " + info.GetCpuName());
            //Console.WriteLine("codename: " + info.CodeName());
            //Console.WriteLine("Cores: " + DataBase.CPU.CoreCount);
            //Console.WriteLine("Threads: " + DataBase.CPU.ThreadCount);
            //Console.WriteLine("Free memory: " + DataBase.Memory.FreeMemory.ToString());

            foreach (var item in DataBase.CpuData)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Free Memory: " + MemInfo.GetAvailableMemory().ToString() + " MB");

            
            // written in C++
            //Console.WriteLine(Imported.add(25, 25));

            Random r = new Random(DateTime.Now.Millisecond);

            try
            {

                do
                {

                    //FibDel1(r.Next(1, 980));


                    // Stress.dll -> Fibonacci
                    Imp.FibD1(r.Next(1, 980));


                } while (true);





            }
            catch (Exception ex)
            {
                const string path = "log" + "_" + "Background2.Task2" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);


            }


        }



        // moved from Background2.cs
        public void Task3(Object stateInfo)
        {
            GC.Collect();

            GC.WaitForFullGCComplete();

            //Garmin.Start();


            //if (_first1)
            Console.WriteLine("Background Task3 is running.");

            //_first1 = false;

            Random r = new(DateTime.Now.Millisecond);

            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 32: 92MB
            for (int i = 0; i < 320; i++)
            {
                Arrs.Add(new Int128[1024 * 10]);
            }

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }


            int[] num = new int[512];


            int[] num2 = new int[512];




            try
            {




                do
                {

                    Imp.RandDel(7);

                } while (true);




            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task3" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source + " Elapsed time: " + Garmin.Elapsed.ToString());
            }




        }

        // for older Thread
        public void Task3T()
        {
            GC.Collect();

            GC.WaitForFullGCComplete();

            //Garmin.Start();


            //if (_first1)
            Console.WriteLine("Background Task3 is running.");

            //_first1 = false;

            Random r = new(DateTime.Now.Millisecond);

            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 32: 92MB
            for (int i = 0; i < 320; i++)
            {
                Arrs.Add(new Int128[1024 * 10]);
            }

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }


            int[] num = new int[512];


            int[] num2 = new int[512];




            try
            {




                do
                {

                    Imp.RandDel(7);

                } while (true);




            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task3" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source + " Elapsed time: " + Garmin.Elapsed.ToString());
            }




        }





        public void Task3Single()
        {
            GC.Collect();

            Garmin.Start();

            Console.WriteLine("Foreground Task3 is running.");



            foreach (var item in DataBase.CpuData)
            {
                Console.WriteLine(item);
            }



            Random r = new Random(DateTime.Now.Millisecond);



            int[] num = new int[512];


            int[] num2 = new int[512];



            try
            {



                do
                {

                    BDel1(num, r.Next(1, 999));

                    BDel1(num2, r.Next(1, 866));


                } while (true);




            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task3" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source + " Elapsed time: " + Garmin.Elapsed.ToString());
            }




        }





        // moved from Background2.cs
        public void Task4(Object stateInfo)
        {
            GC.Collect();

            Garmin.Start();


            Console.WriteLine("Background Task4 is running.");


                


            Random r = new Random(DateTime.Now.Millisecond);



            int[] num = new int[512];


            int[] num2 = new int[512];


            try
            {



                do
                {

                    


                    FactD1(r.Next(1, 866));


                    FactD1(r.Next(1, 866));


                    FactD1(r.Next(1, 866));



                } while (true);

            }



            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task4" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source + " " + " Elapsed time: " + Garmin.Elapsed.ToString());
            }


        }







    }
}

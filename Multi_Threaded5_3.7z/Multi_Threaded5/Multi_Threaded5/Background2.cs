﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    public class Background2 : Background
    {
        /*
        I've disabled inheritance for testing performance penalty, I will replace it with aggregation

        */
          
        public Background2()
        {
            GC.Collect();
            GC.WaitForFullGCComplete();
            Console.Clear();
            

            // cpu_load=1: HeavyLoad; cpu_load=2: ExtremeLoad
            switch (DataBase.Config.CpuLoad)
            {
                case 1:
                    SetThreadsHeavy();
                break;

                case 2:
                    SetThreadsExtreme();
                break;

                case 3:
                    SetThreadsRandom();
                    break;  


             }

        }
 
        // changed task1 -> taskmanager.Task1, task2 -> taskmanager.Task2
        private void SetThreadsHeavy()
        {
            ThreadPool.SetMinThreads(DataBase.CPU.CoreCount, DataBase.CPU.ThreadCount);

            

            //Info.GetThreadCount() - 1
            for (int i = 0; i < DataBase.CPU.ThreadCount - 1; i++)
            {

                // if even
                if (i % 2 == 0)
                {
                    ThreadPool.QueueUserWorkItem(new WaitCallback(DMulti3));
                }

                // if odd
                else
                {
                    ThreadPool.QueueUserWorkItem(new WaitCallback(DMulti3));
                }

            }
    
            // this is the main thread, it must be the last thread
            Foreground foreground = new();
         
        }


        private void SetThreadsExtreme()
        {

            List<Thread> Threads = new List<Thread>();


            for (int i = 0; i < DataBase.CPU.ThreadCount - 1; i++)
            {

                // if even
                if (i % 2 == 0)
                {

                    Threads.Add(new Thread(DMulti3.Invoke, 0));

                    Threads[i].Priority = ThreadPriority.Highest;

                    Threads[i].IsBackground = false; 


                }

                // if odd
                else
                {
                    Threads.Add(new Thread(DMulti3.Invoke, 0));

                    Threads[i].Priority = ThreadPriority.Highest;

                    Threads[i].IsBackground = false;
                    
                    
                }

            }



            foreach (Thread thread in Threads)
                     thread.Start();   



            Foreground foreground = new Foreground();

        }

        private void SetThreadsRandom()
        {
            ThreadPool.SetMinThreads(DataBase.CPU.CoreCount, DataBase.CPU.ThreadCount);

            //ThreadPool.SetMaxThreads(info.GetCoreCount(), info.GetThreadCount());

            //int.Parse(DataBase.CpuData.ElementAt(3).Split(':')[1]) - 1

            //int ThreadCount = int.Parse(DataBase.CpuData.ElementAt(4).Split(':')[1]) - 1;


            //Info.GetThreadCount() - 1
            for (int i = 0; i < DataBase.CPU.ThreadCount - 1; i++)
            {

                // if even
                if (i % 2 == 0)
                {
                    ThreadPool.QueueUserWorkItem(TaskManager.Task3);
                }

                // if odd
                else
                {
                    ThreadPool.QueueUserWorkItem(TaskManager.Task3);
                }

            }


            // this is the main thread, it must be the last thread
            Foreground foreground = new();


        }

    }
     
    }


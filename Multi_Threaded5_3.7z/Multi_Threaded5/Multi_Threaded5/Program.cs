﻿using System;
using System.Runtime.InteropServices;



namespace Multi_Threaded5
{

    /*
       CPU Instructions are already supported in .Net 9.0
       C# Multithreaded stress test
       Created by Danielsson 2025
       This is the new version of Multi Threaded 3.1, upgraded to .Net 9.0.
       This is the .Net 9.0 version with Vector128 and Hardware Instrinsics support.
       (Ver.3.2 - 2025.05.06)
       */


    /*
    Danielsson 2025
    This is an open-source project, you can use it for free without copyright claim.
    Daniel Karacs
    */

    /*
     The main purpose of this program is CPU temperature test in 100% load situation.
      It is not appropriate for stability testing.
      Also, there is an embedded CPU benchmark.
      Some components were written in C++, and are imported from dll folder.
      Memory test has been removed from MultiThreaded.  
     */


/*
Settings guideline for MultiThreaded5:

You can change benchmark modes in benchmark.json by changing bench_mode:
bench_mode=1 (BinarySearch with threadpool), bench_mode=2 (BinarySearch with threads), bench_mode=3 (InterpolationSearch with threadpool), bench_mode=4 (InterpolationSearch with threads)

You can change CPU stress test modes in order to fine-tune stability:
cpu_mode=1 (Fibonacci stress with threadpool), cpu_mode=2 (Fibonacci stress with threads)

The Program Contains C++ written dynamic dlls for better stability and performance. They were exported by using __declspec(dllexport)
Stress.dll contains algorithms for stress testing (Stress.dll must be debug version to use more cpu power)
Benchmark.dll contains algorithms for benchmark session (Benchmark.dll can be both debug or release version. Release versions are faster in general.)
*/

    public class Program
    {


        // foreground threads must be executed last, because the program will stay in infinite loop
        // if you set thread to background, inifnite loops will not affect the main thread
        static void Main()
        {

            //SystemInfo info = new();

            Imported Imported = new();

           
            try
            {
                //long Serial = long.Parse(File.ReadAllText(@"C:\\Program Files\\asd.json"));
                
                // SN.dll checks the serial number from Program Files
                //if (Imported.SNDel() == true)
                //if (DataBase.CPU.CpuID.Contains("178BFBFF00870F10"))
                //{

                    Imported.Mbox(0, "Welcome to Multi Threaded 5(ver3.2), Press OK to continue...", "Multi Threaded 5", 0);

                     
                    byte Menu = 0;

                    GC.Collect();

                    GC.WaitForFullGCComplete();


                    Console.BackgroundColor = ConsoleColor.DarkBlue;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("MultiThreaded5 will stress your CPU, be careful it can cause higher temperatures!" + "\n" + "(If you have cheaper cooler or your CPU is set to auto voltages, try to change it to manual.");
                    Console.WriteLine("Change settings in config.json file");
                    Console.WriteLine("Press 1. to run infinite stress test, Press 2. to run benchmark session, Press 3. to read cpu information");
                    Console.WriteLine("\n#########################################################################################################################################################################################");
                    Console.WriteLine("###########################################################################################################################################################################################");
                    Console.WriteLine("#############################################   2025 Written by Dänielsson  ################################################################################################################");
                    Console.WriteLine("###########################################################################################################################################################################################");
                    Console.WriteLine("####################################################Version 3.2###########################################################################################################################################");
                    Menu = byte.Parse(Console.ReadLine());

                    //Console.ReadKey();
                    //byte.Parse(Console.ReadKey().KeyChar.ToString());


                    //This class will allocate threads, last thread is always the main thread written in Foreground.cs
                    //Background background = new Background();


                    // Background2.cs is already using Threadpool instead of old thread class


                    // 1: stress test, 2: benchmark (Background2 -> stress test), 3: System Information, 4: Memory Stress Test
                    switch (Menu)
                    {
                        case 1:
                            Background2 background2 = new();
                            break;

                        case 2:
                            Benchmark benchmark = new();
                            break;
                        case 3:
                            Systeminfo2 systeminfo2 = new();
                            break;

                        //case 4:
                        //    MemoryStress memory = new();
                        //    break;
                            
                    }
                //}

                //else
                //{
                //    Console.WriteLine("\nUnauthorized user. Access Denied.");

                //    Console.ReadKey();
                //}
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\nUnauthorized user. Access Denied.");
                Console.ReadKey();
            }
        }
    }
}
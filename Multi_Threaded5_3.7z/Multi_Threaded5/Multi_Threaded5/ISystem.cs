﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    internal interface ISystem
    {
        //interface elements must be public in the child class


        string CodeName();

        
        //UInt64 FreeMemory { get; set; }



    }
}

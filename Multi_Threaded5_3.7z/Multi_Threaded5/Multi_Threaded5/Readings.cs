﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
using System.Management;
//using System.Text;
//using System.Threading.Tasks;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    public class Readings
    {
        //protected ManagementObject O { get; set;}

        protected ManagementObjectSearcher Searcher { get; set;}


        //public Readings()
        //{
        //    QueryObj = new ManagementObject();
        //}







    }
}

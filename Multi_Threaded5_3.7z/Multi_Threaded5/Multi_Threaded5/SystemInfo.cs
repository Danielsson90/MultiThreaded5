﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
using System.Management;
using System.IO;
//using System.Threading;
using System.Diagnostics;
using System.ComponentModel;
//using System.Collections.ObjectModel;


//using System.Windows;





namespace Multi_Threaded5
{

   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    public class SystemInfo : Readings
    {


        // I've changed all datatype according to Capitalization rules:
        // PascalCasing for everything except parameters(camelCasing) 2025.04.30
        //changelog: I've changed public datatypes to private to hide from SystemInfo2.cs
        // CPU info
        private string CpuName { get; set;}


        // for stricter serial check
        // 178BFBFF00870F10
        private string CpuID { get; set;}

        private int CoreCount { get; set;}

        private int ClockSpeed { get; set;}

        private int ThreadCount { get; set;}

        // FreeMemory is read only on program execution
        private UInt64 FreeMemory { get; set;}



        //private long FreeMemory2 { get; set;} 


        //private string ID { get; set; }


        //public delegate void d1(Stopwatch garmin, double score);

        //public d1 d1_SaveToFile = null;


        private UInt32 L2CacheSize { get; set;}   


        private UInt32 L3CacheSize { get; set;}


        //private UInt16 LoadPercentage { get; set;}


        private UInt16 Architecture { get; set;}


        private UInt16 Family { get; set;}


        public UInt16 Temp { get; set; }



        //public UInt16 cpu_temp { get; private set;}



        // xml format systeminfo -> SystemInfo2.cs
        protected string Info { get; private set;}

        // for Console.Writeline
        protected string InfoDisplay { get; private set; }




        //public UInt16 os_type { get; private set;}



        //public CpuLoad = byte.Parse(File.ReadAllText(path2).Split('=')[1]);



        private int BenchMode { get; set; }


        private int CpuLoad { get; set; }

        public List<string> CpuDetails { get; private set;}

        // CpuLoad and BenchMode are loaded into InputSettings: they will be read from DataBase.cs
        public IEnumerable<int> InputSettings { get; private set; }


        //public IEnumerable<string> CpuDetails2 { get; private set; }        

        //public ReadOnlyCollection<string> ReadOnlyColls;




            //private string path { get; set; }

            //public string info { get; set;}


            // BIOS information
            // read from Win32_BIOS
            //public string manufacturer_name { get; set; }


            //public string system_name { get; set; }


            // win32_objects list does consist of win32 objects which are required to get information about hardware components 
            //private readonly List<string> win32_objects = new List<string>() {"Win32_Processor","Win32_BIOS","Win32_SMBIOSMemory","Win32_Fan","Win32_PhysicalMemory"};


            // System.Management.dll needs to be added from references in order to use 'ManagementObjectSearcher'


            // You have to run SQL query to get information about the System
            // Essential libraries: Win32_BIOS, Win32_Processor, Win32_Fan, Win32_SMBIOSMemory, Win32_PhysicalMemory
        public SystemInfo()
        {
            this.CpuName = "";
            
            CpuLoad = int.Parse(File.ReadAllText("settings.json").Split('=')[1]);

            BenchMode = int.Parse(File.ReadAllText("benchmark.json").Split('=')[1]);

            

            // Reads cpu info to properties
            QueryInfo();



            //List<int> list = [1, 2, 3];

            // Loads into ReadOnly Collection
            //CpuDetails = new List<string>() {this.CpuName, this.CoreCount.ToString(), this.ClockSpeed.ToString(), this.ThreadCount.ToString(), this.L2CacheSize.ToString(),
            //this.L3CacheSize.ToString(), this.Architecture.ToString(), this.Family.ToString()};

            // simplified version
            CpuDetails = [this.CpuName, this.CoreCount.ToString(), this.ClockSpeed.ToString(), this.ThreadCount.ToString(), this.L2CacheSize.ToString(),
            this.L3CacheSize.ToString(), this.Architecture.ToString(), this.Family.ToString(), this. CpuID];





            // It loads into cpu_details list and cpu_details list is loaded into ReadOnly Collection
            //LoadToList();


            // IEnumerable readonly collection
            //1:cpu_mode, 2:bench_mode
            //InputSettings = new[] {CpuLoad, BenchMode};

            // Simplified version
            InputSettings = [CpuLoad, BenchMode];


            //this.FreeMemory2 = GC.GetTotalMemory(false);


        }



        // query="SELECT * FROM ", objectname="Win32_Processor" string query, string objectname
        private void QueryInfo()
        {       
            try
            {
                Searcher = new ManagementObjectSearcher("SELECT * FROM" + " " + "Win32_Processor");

                //O = new ManagementObject("Win32_Processor");

                //var CpuSearcher = new ManagementObjectSearcher("SELECT * FROM" + " " + "Win32_Processor");

                foreach (ManagementObject queryObj in Searcher.Get())
                {
                    this.CpuName = $"{queryObj["Name"]}";



                    this.CpuID = $"{queryObj["ProcessorId"]}";


                    this.CoreCount = int.Parse($"{queryObj["NumberOfCores"]}");

                    

                    this.ClockSpeed = int.Parse($"{queryObj["CurrentClockSpeed"]}");

                    this.ThreadCount = int.Parse($"{queryObj["NumberOfLogicalProcessors"]}");

                    

                    this.L2CacheSize = UInt32.Parse($"{queryObj["L2CacheSize"]}");

                    this.L3CacheSize = UInt32.Parse($"{queryObj["L3CacheSize"]}");

                    //this.LoadPercentage = UInt16.Parse($"{queryObj["LoadPercentage"]}");


                    this.Architecture = UInt16.Parse($"{queryObj["Architecture"]}");


                    this.Family = UInt16.Parse($"{queryObj["Family"]}");

                    //this.ID = $"{queryObj["DeviceID"]}" + "3MT";


                }

                foreach (var item in Searcher.Get())
                {
                    InfoDisplay = item.GetText(TextFormat.Mof);

                    Info = item.GetText(TextFormat.WmiDtd20);


                }


                //var MemorySearcher = new ManagementObjectSearcher("SELECT * FROM" + " " + "Win32_OperatingSystem");

                Searcher = new ManagementObjectSearcher("SELECT * FROM" + " " + "Win32_OperatingSystem");

                foreach (ManagementObject queryObj in Searcher.Get())
                {
                    this.FreeMemory = UInt64.Parse($"{queryObj["FreePhysicalMemory"]}");

                    
                    //this.os_type = UInt16.Parse($"{queryObj["OSType"]}");



                }

                Searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PerfFormattedData_Counters_ThermalZoneInformation");

                foreach (ManagementObject queryObj in Searcher.Get())
                {
                    this.FreeMemory = UInt64.Parse($"{queryObj["FreePhysicalMemory"]}");

                }

            }


            catch (Exception ex)
            {
                const string Path = "log"+"_"+"QueryInfo"+".txt";

                DateTime date = DateTime.Now;

                Console.WriteLine(date.ToString() + ex.Message + " in QueryInfo ");

                File.WriteAllText(Path, date.ToString() + " error: "+ ex.Message + " details: "+ex.Source);

            }


        }




        public string GetCodeName()
        {

            if (Architecture == 9 && Family == 107)
                return "Matisse";

            //if (Architecture == 9 && Family == 107)
            //    return "Matisse";


            else
                return "N/A";


        }


        public string GetCpuName()
        {
            return CpuName;

        }

        //public int GetCoreCount()
        //{
        //    return CoreCount;
        //}

        //public int GetClockSpeed()
        //{
        //    return ClockSpeed;
        //}

        //public int GetThreadCount()
        //{
        //    return ThreadCount;
        //}

        public UInt64 GetFreeMemory()
        {
            return FreeMemory;
        }

        //public UInt32 GetL2Cache()
        //{
        //    return L2CacheSize;
        //}

        //public UInt32 GetL3Cache()
        //{
        //    return L3CacheSize;
        //}

        //public UInt16 GetCpuLoad()
        //{
        //    return LoadPercentage;
        //}

        //public UInt16 GetArchitecture()
        //{
        //    return Architecture;
        //}


        //public UInt16 GetFamily()
        //{
        //    return Family;
        //}

        //public byte GetBenchMode()
        //{
        //    return BenchMode;
        //}

        //public byte GetCpuLoadMode()
        //{
        //    return CpuLoad;    
        //}


        
        // save to file by adding new line into existing text
        // garmin must be loaded as a parameter
        private void SaveToFile(Stopwatch garmin, double score)
        {
            DateTime Date = DateTime.Now;
            File.AppendAllText("benchmark.txt", "\n" + Date + " CPU: " + this.CpuName + " " + this.ClockSpeed + " " + this.CoreCount + "/" + this.ThreadCount + " render time: " + garmin.Elapsed.ToString() + " rendered_frames: " + score.ToString());


        }

    }
}

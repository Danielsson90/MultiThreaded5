﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */

    public class Imported
    {

        /*

        Imported dlls will be loaded here
        */
        public delegate int MBoxD(IntPtr hWnd, String text, String caption, uint type);


        public delegate double FibonacciD(int n);

        public delegate void RandomD(int seed);

        public delegate long GetScoreD();

        public delegate bool SerialCheckD();

        public delegate string CPUD();




        // it is user32.dll MessageBox
        public readonly MBoxD Mbox = MessageBox;


        // Imported.AddDel
        //public readonly AddD AddDel = add;


        // Stress.dll
        public readonly FibonacciD FibD1 = Fibonacci;

       


        // Stress.dll
        public readonly RandomD RandDel = Random;



        // Benchmark.dll
        public readonly FibonacciD FibD2 = Fibonacci2;


        // import long Score from Benchmark.dll
        public readonly GetScoreD GetScoreDel = GetScore;

        public readonly SerialCheckD SNDel = CheckSerial;

        public readonly CPUD CpuDel = CheckID;



        // I've replaced Windows.Forms MessageBox with built-in windows MessageBox
        // last parameter means the number of buttons
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);




        // it is my own C++ DLL written in C++ 64-bit
        // you need to use extern "C" __declspec(dllexport) method_name(param1, param2); in your cpp files
        [DllImport("Stress.dll")]
        public static extern double Fibonacci(int n);

        [DllImport("Stress.dll")]
        public static extern void Random(int seed);



        [DllImport("Benchmark.dll")]
        public static extern double Fibonacci2(int n);



        [DllImport("Benchmark.dll")]
        public static extern long GetScore();


        [DllImport("SN.dll")]
        public static extern bool CheckSerial();

        [DllImport("SN.dll")]
        public static extern string CheckID();

        [DllImport("SN2.dll")]
        public static extern bool Serial();


        //[DllImport("CPU.dll")]
        //public static extern string CpuID();




        //[DllImport("Benchmark.dll")]
        //public static extern long Score;






    }
}

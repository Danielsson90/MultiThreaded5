﻿using System;
//using System.Collections.Generic;
using System.Diagnostics;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

using System.IO;
//using System.Threading;
using System.Buffers;


namespace Multi_Threaded5
{


    // Benchmarks are located in TaskManager.cs, Stability tests are located in TaskManagerPart2.cs
    // Partial class consists of multiple files, but inheritance must be set only once
    public partial class TaskManager : Complex
    {
        Imported Imp = new();

        // [structs faster than classes]

        // [Aggregation is faster than inheritance]
        //private Complex comp = new Complex();

        //private static SystemInfo info = new SystemInfo();

        
        


        // Memory Optimizations
        public TaskManager()
        {
            GC.Collect();
            GC.WaitForFullGCComplete();              
        }




        // Single Algorithms run only on main thread -> Foreground.cs, Foreground2.cs

        // 2025.05.06:
        // All benchmark algorithm calls has been replaced to delegate invokes
        // Stress test -> 93W, Benchmark -> 83W (Ryzen 3700X 4.20Ghz all core OC)
        // Benchmark scores: (Ryzen 3700X 4.20Ghz: 1950-2030)
        public void MTBenchSingle()
        {                      
            Garmin.Start();

                       
            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);

           
            int[] num = new int[512];

            int[] num2 = new int[512];

            

            for (int i = 0; i < num.Length; i++)
            {
                num[i] = r.Next(1, 999);

                num2[i] = r.Next(1, 999);
            }

          
            try
            {


            
                

                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {
                    Interval.Start();

                 
                    //FibDel2(256);

                    Imp.FibD2(256);


                    if (Interval.ElapsedMilliseconds > 999)
                    {
                        Console.Write("-");
                        Interval.Restart();    
                    }

                }


                Garmin.Stop();



                //DataBase.d1_pointer(Garmin, Score / 1000000);

                DataBase.d1_pointer(Garmin, Imp.GetScoreDel() / 1000000);

                DataBase.NextMethod();

                //DataBase.d1_pointer(Garmin, Score / 1000000);

                DataBase.d1_pointer(Garmin, Imp.GetScoreDel() / 1000000);


                Console.ReadKey();


 

            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }

        




        
        // multi algorithms run on all background threads -> Benchmark.cs, Background2.cs
        // runs on background threads: Threadpool
        public void MTBenchMulti(Object stateInfo)
        {
            
            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);


            int[] num = new int[512];


            int[] num2 = new int[512];

           

            for (int i = 0; i < num.Length; i++)
            {
                num[i] = r.Next(1, 999);

                num2[i] = r.Next(1, 999);

            }

            try
            {

                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {
                 
                    //FibDel2(666);

                    
                    Imp.FibD2(666);
                  
                }

            

            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }

        // runs on background threads -> Thread
        public void MTBenchMultiT()
        {

            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);


            int[] num = new int[512];


            int[] num2 = new int[512];



            for (int i = 0; i < num.Length; i++)
            {
                num[i] = r.Next(1, 999);

                num2[i] = r.Next(1, 999);

            }

            try
            {

                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {

                    //FibDel2(666);

                    Imp.FibD2(666);

                }



            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }



        public void MTBenchSingle2()
        {
            Garmin.Start();


            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);


            byte[] num = new byte[255];

            byte[] num2 = new byte[255];



            for (int i = 0; i < num.Length; i++)
            {
                num[i] = 2;



                num2[i] = 4;
            }


            try
            {





                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {
                    Interval.Start();


                    //FibDel2(256);

                    IDel1(num, 0);



                    if (Interval.ElapsedMilliseconds > 999)
                    {
                        Console.Write("-");
                        Interval.Restart();
                    }

                }


                Garmin.Stop();



                DataBase.d1_pointer(Garmin, Score / 1000000);

                DataBase.NextMethod();

                DataBase.d1_pointer(Garmin, Score / 1000000);


                Console.ReadKey();




            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }


        // multi algorithms run on all background threads -> Benchmark.cs, Background2.cs
        // runs on background threads: Threadpool
        public void MTBenchMulti2(Object stateInfo)
        {

            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);


            byte[] num = new byte[255];


            byte[] num2 = new byte[255];



            for (int i = 0; i < num.Length; i++)
            {
                num[i] = 2;

                num2[i] = 4;

            }

            try
            {

                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {

                    //FibDel2(666);

                    IDel1(num, 1);

                }



            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }

        // runs on background threads -> Thread
        public void MTBenchMulti2T()
        {

            Console.WriteLine("Benchmark is running! until 20000 miliseconds.");

            Random r = new Random(DateTime.Now.Millisecond);


            int[] num = new int[512];


            int[] num2 = new int[512];



            for (int i = 0; i < num.Length; i++)
            {
                num[i] = r.Next(1, 999);

                num2[i] = r.Next(1, 999);

            }

            try
            {

                //200000
                for (int i = 0; Garmin.ElapsedMilliseconds < 200000; i++)
                {

                    //FibDel2(666);

                    Imp.FibD2(666);

                }



            }
            catch (Exception ex)
            {


                const string path = "log" + "_" + "Background2.Task1" + ".txt";


                DateTime date = DateTime.Now;


                Console.WriteLine(ex.Message);


                File.WriteAllText(path, date.ToString() + " " + ex.Message + " " + ex.Source);
            }


        }









        //


    }
}

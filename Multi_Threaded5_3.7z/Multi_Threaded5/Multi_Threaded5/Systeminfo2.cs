﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Security.Principal;
//using System.Runtime.InteropServices;



namespace Multi_Threaded5
{
   /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    public class Systeminfo2 : SystemInfo
    {
        private readonly string Path = "cpu_info.xml";

        private string Input { get; set;}

        //Imported Imported = new Imported();

        private readonly Imported Imported = new();

        public Systeminfo2()
        {
            this.Input = "";
            Console.Clear();
            Console.WriteLine("\nSystem Information:");
            Console.WriteLine("\n" + InfoDisplay);

            //Console.WriteLine(Imported.CpuID());

            




            Console.WriteLine("Press 's' to save to an .xml file or press 'q' to return to the menu");
            Input = Console.ReadKey().KeyChar.ToString();

            Console.ReadKey();


            switch (Input)
            {
                case "s":
                    SaveInfo();
                    break;


                case "q":
                    BackToMenu();
                    break;




            }
     
        }

    // If you need Windows MessageBox written in C++ you can import from user32.dll
   //     [DllImport("user32.dll", CharSet = CharSet.Unicode)]
   //     private static extern int MessageBox(
   //IntPtr owner,
   //string message,
   //string title,
   //uint type);




        private void SaveInfo()
        {
            DateTime Date = DateTime.Now;
            

            if (!File.Exists(Path))
                File.WriteAllText(Path, Info + "\n" + Date);


            if (File.Exists(Path))
                File.AppendAllText(Path, Info + "\n" + Date);

            Console.WriteLine("xml has been created. " + "\n" + Date);

            Imported.Mbox(new IntPtr(0), "xml has been created." + "\n" + Date + "\n" + Path, "Multi_Threaded5", 1);

            //MessageBox(IntPtr.Zero, "xml has been created. " + "\n" + Date, "Multi Threaded 3.1", 0);


            BackToMenu();

        }


        private static void BackToMenu()
        {
            string path = "Multi_Threaded5.exe";
            Process.Start(path);
            //Application.Exit();
            Console.Clear();
            //Environment.Exit(0);           
            // Starts a new instance of the program itself            
            // Closes the current process
            //Environment.Exit(0);
        }





    }
}

﻿//using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.Buffers;
using System.Diagnostics;
using System.IO;





namespace Multi_Threaded5
{


    // 2025.05.07
    // Complex 2 contains memory diagnostic algorithms to stress the RAM and memory controller
    // This class does contain Complex Math algorithms that can stress the cpu and memory
    public class Complex2 : Complex
    {
        protected Imported Imported = new();

        private Int128 R1 { get; set;}

        private Int128 R2 { get; set; }

        protected delegate void MemDel1(int freeMemory);


        protected readonly MemDel1 MemD1_M;

        protected readonly MemDel1 MemD1_S;


        public Complex2()
        {
            R1 = new Int128(3402823669209384634, 1111111);

            R2 = new Int128(3402823669209384634, 1234);

            MemD1_M = TestAllMemory_Multi;

            MemD1_S = TestAllMemory_Single;  

        }




        private void TestAllMemory_Multi(int freeMemory)
        {
            DateTime Date = DateTime.Now;

            Random r = new(Date.Microsecond);

            int Seed = r.Next(5, 10);

            Random r2 = new(Date.Microsecond * Seed);

            int V1 = r2.Next(100, 999);

            int V2 = r2.Next(100, 999);

            int V3 = r2.Next(100, 999);

            int V4 = r2.Next(100, 999);

            //Garmin.Start();


            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();

            Int128[] Copy = new Int128[1500 * 100];


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 1800: 6300MB


            for (int i = 0; i < freeMemory / 42; i++)
            {
                Arrs.Add(new Int128[1500 * 100]);
            }

            //for (int i = 0; i < 5; i++)
            //{
            //    Containers.A.Add(UInt128.MaxValue);
            //}

            //for (int i = 0; i < freeMemory / 92; i++)
            //{
            //    Containers.B.Add(UInt128.MaxValue - (UInt128)V2);
            //}

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }

            for (int i = 0; i < Arrs.Count; i++)
            {
                Arrs.Add(Arrs.ElementAt(i));
            }

            //foreach (var item in Containers.A)
            //{
            //    item.ToString();
            //}


            //for (int i = 0; Garmin.Elapsed.Milliseconds < 1000; i++)
            //{



            //    BDel2(Arrs[1], i);


            //    //Buffer.BlockCopy(Arr1, 1, Arr2, 2, 2);


            //    //foreach (var item in Arrs)
            //    //{
            //    //    BDel2(item, R1);
            //    //}



            //    //Buffer.BlockCopy(Arrs[0], 10, Arrs[1], 20, 3);





            //}
        }



        private void TestAllMemory_Single(int freeMemory)
        {
            DateTime Date = DateTime.Now;

            Random r = new(Date.Microsecond);

            Garmin.Start();



            // List containing Int128 arrays
            List<Int128[]> Arrs = new List<Int128[]>();


            // numer of arrays determine memory consumption
            // it must be read from config file
            // 1800: 6300MB
            for (int i = 0; i < freeMemory / 64; i++)
            {
                Arrs.Add(new Int128[1500 * 10]);
            }

            // min: 0, max: 10240
            foreach (var item in Arrs)
            {

                for (int i = 0; i < item.Length; i++)
                {
                    item[i] = i + 1;
                }
            }






            for (int i = 0; i < Arrs.Count; i++)
            {


                BDel2(Arrs[i], r.Next(1, 15000));

                    Interval.Start();

                    //Buffer.BlockCopy(Arr1, 1, Arr2, 2, 2);

                    //foreach (var item in Arrs)
                    //{
                    //    BDel2(item, R1);
                    //}


                    if (Interval.ElapsedMilliseconds > 999)
                    {
                        Console.Write("-");

                        Interval.Restart();
                    }
       

            }
        }




    }




}

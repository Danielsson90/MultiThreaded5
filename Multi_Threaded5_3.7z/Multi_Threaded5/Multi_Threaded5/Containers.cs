﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded5
{
    // 2025.07.09
    // Containers class is used for Memory Tests
    public static class Containers
    {

        public static List<UInt128> A = new List<UInt128>();

        public static List<UInt128> B = new List<UInt128>();

        public static List<UInt128> C = new List<UInt128>();

        public static List<UInt128> D = new List<UInt128>();

        public static List<Int128[]> Arrs = new List<Int128[]>();

    }
}

﻿using System;


namespace Multi_Threaded5
{

    /*
   Danielsson 2025
   This is an open-source project, you can use it for free without copyright claim.
   Daniel Karacs
   */
    public class Background
    {
        // TaskManager is inhereted by Classes that run the Complex tasks
        // in theory, Inheritance is a bit slower than creating new objects
        protected TaskManager TaskManager = new TaskManager();


        // runs on main thread
        protected delegate void DSingleTask();

        // runs on background threads: Threadpool
        // stateInfo parameter is mandatory for threadpool tasks
        protected delegate void DMultiTask(Object stateInfo);

        // runs on background threads: thread
        protected delegate void DMulti();

        // single-cast readonly delegate
        protected readonly DSingleTask DSingle1;
        protected readonly DSingleTask DSingle2;
        protected readonly DSingleTask DSingle3;
        protected readonly DSingleTask DSingle4;    

        // single-cast readonly delegate
        protected readonly DMultiTask DMulti1;

        protected readonly DMulti DMulti1T;
        protected readonly DMulti DMulti2T;
        protected readonly DMulti DMulti3T;
        protected readonly DMultiTask DMulti2;
        protected readonly DMultiTask DMulti3;
        protected readonly DMultiTask DMulti4;  


        public Background()
        {
            DSingle1 = TaskManager.MTBenchSingle;

            DMulti1 = TaskManager.MTBenchMulti;

            DMulti1T = TaskManager.MTBenchMultiT;
            
            // it will be called from Foreground3.cs
            DSingle2 = TaskManager.MTBenchSingle2;

            DMulti2 = TaskManager.MTBenchMulti2;

            DMulti2T = TaskManager.MTBenchMulti2T;

            //**2025.10.05**
            // stability tests:
            // T stands for empty parameter list for older Thread control,
            // while without T means Object stateinfo parameter for newer ThreadPool
            DSingle3 = TaskManager.Task2Single;

            // ThreadPool
            DMulti3 = TaskManager.Task2;
            // Thread
            DMulti3T = TaskManager.Task2T;

        }

      




    }
}
